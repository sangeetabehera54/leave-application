INSERT INTO `roles` (`name`) VALUES ('DEVELOPER');
INSERT INTO `roles` (`name`) VALUES ('MANAGER');


INSERT INTO `users` (`email`,`full_name`, `password`, `enabled`) VALUES ('Sangeeta@gmail.com','Sangeeta', '$2a$10$cTUErxQqYVyU2qmQGIktpup5chLEdhD2zpzNEyYqmxrHHJbSNDOG.', '1');
INSERT INTO `users` (`email`,`full_name`, `password`, `enabled`) VALUES ('Vijay@gmail.com','Vijay', '$2a$10$.tP2OH3dEG0zms7vek4ated5AiQ.EGkncii0OpCcGq4bckS9NOULu', '1');
INSERT INTO `users` (`email`,`full_name`, `password`, `enabled`) VALUES ('Ambarish@gmail.com','Ambarish',  '$2a$10$E2UPv7arXmp3q0LzVzCBNeb4B4AtbTAGjkefVDnSztOwE7Gix6kea', '1');
INSERT INTO `users` (`email`, `full_name`,`password`, `enabled`) VALUES ('Rohit@gmail.com','Rohit',  '$2a$10$GQT8bfLMaLYwlyUysnGwDu6HMB5G.tin5MKT/uduv2Nez0.DmhnOq', '1');


INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (1, 1); -- user sangeeta has role DEVELOPER
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (2, 2); -- user Vijay has role MANAGER
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (3, 2); -- user Ambarish has role MANAGER
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (4, 1); -- user Rohit has role DEVELOPER

