package com.nous.leave.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nous.leave.dao.LeaveManageRepository;
import com.nous.leave.models.Leave;

@Service
public class LeaveService {

	@Autowired
	LeaveManageRepository leaveManageRepository;

	public void applyLeave(Leave leaveDetails) {

		int duration = leaveDetails.getToDate().getDate() - leaveDetails.getFromDate().getDate();
		leaveDetails.setDuration(duration + 1);
		leaveManageRepository.save(leaveDetails);
	}

	public Leave getLeaveDetailsOnId(int id) {

		return leaveManageRepository.getInfoById(id);
	}

	public void updateLeaveDetails(Leave leaveInfo) {
		leaveManageRepository.save(leaveInfo);
	}
}
