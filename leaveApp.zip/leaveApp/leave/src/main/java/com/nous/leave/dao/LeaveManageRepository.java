package com.nous.leave.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nous.leave.models.Leave;

public interface LeaveManageRepository extends JpaRepository<Leave, Integer> {
	
	@Query(nativeQuery = true, value = "select l from leaves l where id := id")
	public Leave getInfoById(int id);

}
