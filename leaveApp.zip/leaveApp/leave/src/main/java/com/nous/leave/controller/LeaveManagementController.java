package com.nous.leave.controller;

import javax.validation.constraints.NotBlank;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nous.leave.models.Leave;
import com.nous.leave.service.LeaveService;
import com.nous.leave.utilities.RecordNotFoundException;

@Controller
@RequestMapping("/v2")
public class LeaveManagementController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LeaveManagementController.class);
	@Autowired
	private LeaveService leaveService;

	/*
	 * Method for applying leave
	 */
	@PostMapping(value = "/applyLeave", consumes = "application/json", produces = "application/json")
	public void applyLeave(@RequestParam @NotBlank String username, @RequestBody @NotBlank Leave leaveInfo) {
		leaveService.applyLeave(leaveInfo);
	}

	/*
	 * Method for approval and Rejection of leaves by the manager
	 * 
	 */
	@GetMapping("/edit/approveOrRejectLeaves")
	public void approveOrRejectLeaves(@PathVariable("username") @NotBlank String username,
			@PathVariable("action") @NotBlank String action, @PathVariable("id") @NotBlank int id) {

		Leave leaveinfo = leaveService.getLeaveDetailsOnId(id);
		LOGGER.error("USername not found for id" + id);
		if (action.equals("accept")) {
			leaveinfo.setAcceptRejectFlag(true);
		} else if (action.equals("reject")) {
			leaveinfo.setAcceptRejectFlag(false);
		}
		leaveService.updateLeaveDetails(leaveinfo);

		LOGGER.error("Username not for id " + id);
	}
	
	/*
	 * Method for Getting leaves info
	 * 
	 */
	@GetMapping("/getLeaves")
	public ResponseEntity<Leave> getLeaves(@PathVariable("email") @NotBlank String username, @PathVariable("id") @NotBlank int id) throws RecordNotFoundException {
		Leave leaveInfo = leaveService.getLeaveDetailsOnId(id);
		
		if(leaveInfo == null) {
			throw new RecordNotFoundException("Record not found");
		}
		return new ResponseEntity<Leave>(leaveInfo, HttpStatus.OK);
	}
}
